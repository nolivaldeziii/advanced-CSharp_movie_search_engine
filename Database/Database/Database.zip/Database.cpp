#include "Database.h"

void Database::RetrieveMovieNames()
{
	/*
	open input filestream
	read movie names from list
	save to linklist
	*/
}

void Database::RetrieveUserNames()
{
	/*
	open input filestream
	read usernames from list
	save to linklist
	*/
}

Movie Database::RetrieveMovie(char*)
{
	/*
	check if a movie match from database
	if match return read the userdata and return the class
	else return null
	*/
}

void Database::RetrieveUser(char*)
{
	//same idea with the movie
}

bool Database::IsUpdate(char*)
{
	//if the upasdas
}

void Database::AddMovie(char*)
{
	//ADD MOVIE!!!!
}
