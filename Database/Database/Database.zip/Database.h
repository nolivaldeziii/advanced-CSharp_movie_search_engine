#pragma once

#include "C:\\Users\\Noli\\Dropbox\\Programming\\Projects\\Movie Search Engine\\MovieClass\\MovieClass\\linklist.cpp"
#include "C:\\Users\\Noli\\Dropbox\\Programming\\Projects\\Movie Search Engine\\MovieClass\\MovieClass\\Movie_Class.h"
#include "C:\\Users\\Noli\\Dropbox\\Programming\\Projects\\Movie Search Engine\\MovieClass\\MovieClass\\Movie_Class.cpp"

class Database
{
private:
	char* MainFolder; // working directory is where the main.exe is
	char* MovieFolder;
	char* UserFolder;
	char* UserDataLocation;
	char* MovieDataLocation;

public:
	Link<char*> AllMovieList; //title only
	Link<char*> AllUserList; // usernames only
	char* LastUpdate;

	bool DataFilled;

	void RetrieveMovieNames();
	void RetrieveUserNames();
	Movie RetrieveMovie(char*);
	void RetrieveUser(char*);

	bool IsUpdate(char*);
	void AddMovie(char*);

};